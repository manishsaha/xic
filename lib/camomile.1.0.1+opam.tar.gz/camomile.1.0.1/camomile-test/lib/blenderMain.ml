(* $Id: blenderMain.ml,v 1.1.1.1 2002/11/13 02:49:20 yori Exp $ *)
(* Copyright 2002 Yamagata Yoriyuki *)

let _ = Blender.main ()
