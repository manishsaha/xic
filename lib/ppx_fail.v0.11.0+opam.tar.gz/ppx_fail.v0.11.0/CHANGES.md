## v0.11

- Depend on ppxlib instead of (now deprecated) ppx\_core, ppx\_driver and
  ppx\_metaquot.

## 113.43.00

- use the new context-free API

## 113.24.00

- Added a README.md

- Update to follow `Ppx_core` evolution.
