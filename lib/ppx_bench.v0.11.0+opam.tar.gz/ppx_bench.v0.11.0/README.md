ppx_bench
=========

Syntax extension for writing in-line benchmarks in OCaml code.

For documentation and examples, see:

    example/ppx_bench_sample.ml
