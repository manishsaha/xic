[%%define C B]
