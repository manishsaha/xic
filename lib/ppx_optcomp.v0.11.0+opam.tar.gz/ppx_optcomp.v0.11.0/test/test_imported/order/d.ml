[%%define D C]
