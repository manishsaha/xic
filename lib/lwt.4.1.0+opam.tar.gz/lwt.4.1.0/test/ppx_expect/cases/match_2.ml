let _ =
  match%lwt
    ()
  with
  | () ->
    Lwt.return ();;
