let () =
  Lwt_preemptive.simple_init |> ignore
