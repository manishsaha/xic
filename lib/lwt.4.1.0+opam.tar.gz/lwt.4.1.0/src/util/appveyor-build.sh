set -e
set -x

make build
make test
