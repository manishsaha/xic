ppx_bin_prot
============

Generation of binary serialization and deserialization functions from type definitions.
There's more information about:

- The [bin-prot format](file:../../lib/bin_prot/README.md) 
- [bin-prot-shape](../../lib/bin_prot/shape/README.md), which is useful for checking
  compatibility of the `bin_prot` representations of different types.
