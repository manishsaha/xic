## v0.11.1

- Update for AST 4.06

## v0.11

Depend on ppxlib instead of (now deprecated) ppx\_core, ppx\_driver and
ppx\_type\_conv.

## 113.43.00

- use the new context-free API

## 113.24.01

- Fix the META. ppx\_bin\_prot was not previously treated as a
  ppx\_deriving plugin, which was causing problems

## 113.24.00

- Minor changes, nothing worth mentionning.
