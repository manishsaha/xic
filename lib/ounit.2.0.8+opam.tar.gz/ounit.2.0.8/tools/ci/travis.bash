OPAMROOT="$HOME/.opam"
. $(dirname "$0")/build.bash
