(* OASIS_START *)
(* DO NOT EDIT (digest: 7972011e467ce4298adee5afbb353623) *)

ounit - Unit testing framework
==============================

OUnit is a unit testing framework for OCaml, inspired by the JUnit tool for
Java, and the HUnit tool for Haskell.

More information on [HUnit](http://hunit.sourceforge.net)

See the file [INSTALL.txt](INSTALL.txt) for building and installation
instructions.

[Home page](http://ounit.forge.ocamlcore.org)

Copyright and license
---------------------

(C) 2002-2008 Maas-Maarten Zeeman
(C) 2010 OCamlCore SARL

ounit is distributed under the terms of the MIT License.

See [LICENSE.txt](LICENSE.txt) for more information.

(* OASIS_STOP *)
