## v0.11

- Depend on ppxlib instead of (now deprecated) ppx\_core, ppx\_driver and
  ppx\_metaquot.

## 113.43.00

- Allow to use `sexp_option` in more places in ppx\_sexp\_value, to make it
  to display information only some of the time.
