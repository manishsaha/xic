# v0.12.0

- Breaking change: make environments abstract so that we can later
  optimize them without further breaking changes (#3)

# v0.11.1

- Fix linking errors due to missing `-lphtread` (#1)

# v0.9.0

Initial release
