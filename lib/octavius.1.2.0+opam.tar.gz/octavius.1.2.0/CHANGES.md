v1.2.0
------

- Follow odoc evolution.

v1.1.0
------

- switch build to jbuilder.

- changed versionning to be in sync with the other odoc packages.

v0.2.0
-------

Added "@canonical" tag.

v0.1.0
-------

Initial opam release.
