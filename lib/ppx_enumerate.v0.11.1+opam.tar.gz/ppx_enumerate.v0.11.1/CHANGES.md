## v0.11.1

- Update for AST 4.06

## v0.11

Depend on ppxlib instead of (now deprecated) ppx\_core, ppx\_driver,
ppx\_metaquot and ppx\_type\_conv.

## 113.24.00

- Update to follow type\_conv evolution.
