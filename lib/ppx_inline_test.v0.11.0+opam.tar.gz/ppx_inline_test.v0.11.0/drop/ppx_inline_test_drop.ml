let () = Ppx_inline_test.set_default_maybe_drop Drop
