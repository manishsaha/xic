#include <caml/mlvalues.h>

CAMLprim value Base_am_testing()
{
  return Val_true;
}

CAMLprim value Base_boot_am_testing()
{
  return Val_true;
}
