let%expect_test _ =
  print_string "\
foo
bar
";
  [%expect ""]
;;
